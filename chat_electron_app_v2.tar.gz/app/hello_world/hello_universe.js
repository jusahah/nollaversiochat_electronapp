var greet = function () {
    return 'Hello Universe!';
};

export default greet;
