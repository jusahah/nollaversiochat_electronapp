export var greet = function () {
    return 'Hello World!';
};

export var bye = function () {
    return 'See ya!';
};
